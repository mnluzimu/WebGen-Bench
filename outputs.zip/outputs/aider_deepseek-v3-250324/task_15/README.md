# Solar Company Website

A modern website for a solar energy company built with React and Vite.

## Features
- Company introduction (history, mission, values)
- Product showcase
- News updates
- Contact form

## Installation
1. Clone the repository
2. Run `npm install`
3. Run `npm run dev` to start development server

## Scripts
- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm run preview`: Preview production build
- `npm run lint`: Run ESLint

## Technologies
- React 18
- React Router 6
- Vite
