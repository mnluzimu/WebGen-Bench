import ProductCard from '../components/ProductCard'

const products = [
  // ... products array remains the same ...
]

export default function Products() {
  return (
    <div>
      <h1>Our Products</h1>
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
        gap: '2rem',
        marginTop: '2rem'
      }}>
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
