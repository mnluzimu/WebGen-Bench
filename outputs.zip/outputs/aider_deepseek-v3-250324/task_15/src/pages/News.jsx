import NewsCard from '../components/NewsCard'

const newsItems = [
  // ... news items array remains the same ...
]

export default function News() {
  return (
    <div>
      <h1>Latest News</h1>
      <div style={{ marginTop: '2rem' }}>
        {newsItems.map(news => (
          <NewsCard key={news.id} news={news} />
        ))}
      </div>
    </div>
  )
}
