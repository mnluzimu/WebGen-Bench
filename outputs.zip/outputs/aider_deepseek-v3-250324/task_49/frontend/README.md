# Women's Health Survey

A comprehensive health survey platform for women with admin dashboard capabilities.

## Features

- Health survey form with multiple fields
- Secure admin login
- Submission management dashboard
- Responsive design

## Setup

1. Install dependencies:
