import React from 'react'
import ConsolidatedChart from '../components/ConsolidatedChart'

const ConsolidatedReport = () => {
  // Sample consolidated data
  const consolidatedData = [
    { name: 'Tech Corp', revenue: 5000000, profit: 1200000 },
    { name: 'Finance Inc', revenue: 3000000, profit: 800000 },
    { name: 'Retail Group', revenue: 2500000, profit: 600000 }
  ]

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6 teal-text">Consolidated Financial Report</h1>
      <ConsolidatedChart data={consolidatedData} />
    </div>
  )
}

export default ConsolidatedReport
