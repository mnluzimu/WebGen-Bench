import React from 'react'
import ComparisonChart from '../components/ComparisonChart'

const ComparisonTool = () => {
  // Sample comparison data
  const comparisonData = [
    { name: 'Revenue', TechCorp: 5000000, FinanceInc: 3000000, RetailGroup: 2500000 },
    { name: 'Profit', TechCorp: 1200000, FinanceInc: 800000, RetailGroup: 600000 },
    { name: 'Employees', TechCorp: 250, FinanceInc: 180, RetailGroup: 150 }
  ]

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6 teal-text">Company Comparison Tool</h1>
      <ComparisonChart data={comparisonData} />
    </div>
  )
}

export default ComparisonTool
