module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#191970', // midnight blue
          light: '#2a2a8a',
          dark: '#0e0e4d'
        },
        background: '#007FFF', // azure
      },
    },
  },
  plugins: [],
}
