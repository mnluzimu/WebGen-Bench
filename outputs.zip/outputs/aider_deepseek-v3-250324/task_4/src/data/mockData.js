export const mockPolicies = [
  {
    id: '1',
    title: 'Environmental Protection Act',
    category: 'Environment',
    description: 'Regulates industrial emissions and waste management practices to protect the environment.',
    effectiveDate: '2023-01-15',
    chartData: {
      labels: ['2019', '2020', '2021', '2022', '2023'],
      values: [120, 135, 110, 95, 80]
    }
  },
  {
    id: '2',
    title: 'Data Privacy Regulation',
    category: 'Technology',
    description: 'Sets standards for personal data collection, storage, and processing by organizations.',
    effectiveDate: '2022-07-01',
    chartData: {
      labels: ['Q1', 'Q2', 'Q3', 'Q4'],
      values: [45, 60, 75, 90]
    }
  },
  {
    id: '3',
    title: 'Financial Services Compliance',
    category: 'Finance',
    description: 'Requirements for anti-money laundering and fraud prevention in banking institutions.',
    effectiveDate: '2023-03-10',
    chartData: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
      values: [200, 180, 220, 240, 210]
    }
  }
]
