export default function Footer() {
  return (
    <footer style={{ 
      backgroundColor: 'olivedrab', 
      color: 'white', 
      padding: '1rem', 
      textAlign: 'center',
      marginTop: 'auto'
    }}>
      <p>© 2024 PhoneOperator. All rights reserved.</p>
    </footer>
  )
}
