export default function Home() {
  return (
    <div>
      <h1>Welcome to PhoneOperator</h1>
      <p>Your trusted mobile service provider</p>
    </div>
  )
}
