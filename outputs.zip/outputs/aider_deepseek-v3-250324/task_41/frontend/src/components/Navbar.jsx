import { AppBar, Toolbar, Button, Box } from '@mui/material'
import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <AppBar position="static" sx={{ bgcolor: 'peru' }}>
      <Toolbar>
        <Box sx={{ flexGrow: 1, display: 'flex', gap: 2 }}>
          <Button color="inherit" component={Link} to="/">
            Compose
          </Button>
          <Button color="inherit" component={Link} to="/sent">
            Sent
          </Button>
          <Button color="inherit" component={Link} to="/templates">
            Templates
          </Button>
          <Button color="inherit" component={Link} to="/recipients">
            Recipients
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  )
}
