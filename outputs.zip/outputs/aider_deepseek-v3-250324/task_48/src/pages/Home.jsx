import styled from 'styled-components'

const Container = styled.div`
  padding: 2rem;
`

export default function Home() {
  return (
    <Container>
      <h1>Welcome to Barber Shop Management</h1>
      <p>Manage your barbers, services, and client notifications</p>
    </Container>
  )
}
