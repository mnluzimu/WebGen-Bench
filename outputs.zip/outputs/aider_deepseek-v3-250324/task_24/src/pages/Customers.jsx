import { Box, Typography, Button } from '@mui/material'
import CustomerTable from '../components/CustomerTable'

export default function Customers() {
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">Customer Management</Typography>
        <Button variant="contained">Add Customer</Button>
      </Box>
      <CustomerTable />
    </Box>
  )
}
