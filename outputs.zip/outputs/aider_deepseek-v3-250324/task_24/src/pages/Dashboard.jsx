import { Box, Typography } from '@mui/material'
import CustomerStats from '../components/CustomerStats'
import PolicyStats from '../components/PolicyStats'
import ClaimStats from '../components/ClaimStats'

export default function Dashboard() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Insurance Dashboard
      </Typography>
      <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
        <CustomerStats />
        <PolicyStats />
        <ClaimStats />
      </Box>
    </Box>
  )
}
