import { Box, Typography, Button } from '@mui/material'
import ClaimTable from '../components/ClaimTable'

export default function Claims() {
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">Claim Management</Typography>
        <Button variant="contained">File Claim</Button>
      </Box>
      <ClaimTable />
    </Box>
  )
}
