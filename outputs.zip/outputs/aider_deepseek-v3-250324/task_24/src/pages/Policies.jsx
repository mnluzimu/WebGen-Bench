import { Box, Typography, Button } from '@mui/material'
import PolicyTable from '../components/PolicyTable'

export default function Policies() {
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">Policy Management</Typography>
        <Button variant="contained">Create Policy</Button>
      </Box>
      <PolicyTable />
    </Box>
  )
}
