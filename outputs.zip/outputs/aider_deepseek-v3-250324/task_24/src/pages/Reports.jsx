import { Box, Typography } from '@mui/material'
import SalesChart from '../components/SalesChart'
import ClaimAnalysis from '../components/ClaimAnalysis'

export default function Reports() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Reports & Analytics
      </Typography>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <SalesChart />
        <ClaimAnalysis />
      </Box>
    </Box>
  )
}
