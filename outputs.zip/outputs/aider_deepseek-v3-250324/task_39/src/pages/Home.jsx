import styled from 'styled-components'
import { HeroSection, FeaturedServices, Testimonials } from '../components'

const HomeContainer = styled.div`
  padding: 2rem;
  flex: 1;
`

export default function Home() {
  return (
    <HomeContainer>
      <HeroSection />
      <FeaturedServices />
      <Testimonials />
    </HomeContainer>
  )
}
