export default function Articles() {
  return (
    <div className="articles">
      <h1>Technical Articles</h1>
      <p>Browse our collection of technical articles</p>
    </div>
  )
}
