export default function Solutions() {
  return (
    <div className="solutions">
      <h1>Technical Solutions</h1>
      <p>Find solutions to common technical problems</p>
    </div>
  )
}
