export default function Search() {
  return (
    <div className="search">
      <h1>Search Technical Content</h1>
      <p>Find exactly what you're looking for</p>
    </div>
  )
}
