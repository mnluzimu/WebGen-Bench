export default function Home() {
  return (
    <div className="home">
      <h1>Welcome to TechSolutions Hub</h1>
      <p>Your one-stop resource for technical articles and solutions</p>
    </div>
  )
}
