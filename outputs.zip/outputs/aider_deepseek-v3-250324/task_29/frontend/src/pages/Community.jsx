export default function Community() {
  return (
    <div className="community">
      <h1>Community Discussions</h1>
      <p>Connect with other technical professionals</p>
    </div>
  )
}
