export default function GameSimulation({ teams }) {
  return (
    <div className="game-simulation">
      <h1>Game Simulation</h1>
      {/* Game simulation UI will go here */}
    </div>
  )
}
