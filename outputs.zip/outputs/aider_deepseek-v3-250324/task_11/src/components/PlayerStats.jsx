export default function PlayerStats({ players }) {
  return (
    <div className="player-stats">
      <h1>Player Statistics</h1>
      {/* Player stats UI will go here */}
    </div>
  )
}
