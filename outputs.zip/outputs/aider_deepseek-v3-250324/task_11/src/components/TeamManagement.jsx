export default function TeamManagement({ teams, setTeams }) {
  return (
    <div className="team-management">
      <h1>Team Management</h1>
      {/* Team management UI will go here */}
    </div>
  )
}
