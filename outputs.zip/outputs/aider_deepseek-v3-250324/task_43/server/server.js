const express = require('express')
const sqlite3 = require('sqlite3').verbose()
const cors = require('cors')

const app = express()
const port = 5000

app.use(cors())
app.use(express.json())

// Database initialization and routes would follow here
// ... [previous database and route code] ...

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`)
})
