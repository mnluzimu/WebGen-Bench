import Chatbot from './components/Chatbot'

function App() {
  return (
    <div className="app">
      <h1>Welcome to Our Store</h1>
      <Chatbot />
    </div>
  )
}

export default App
