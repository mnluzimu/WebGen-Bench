export default function About() {
  return (
    <div className="container">
      <h1>About Our Practice</h1>
      <section>
        <h2>Our History</h2>
        <p>Founded in 2010, our clinical office has been serving the community with dedication and expertise.</p>
      </section>
      <section>
        <h2>Our Team</h2>
        <p>Meet our team of experienced healthcare professionals committed to your well-being.</p>
      </section>
    </div>
  )
}
