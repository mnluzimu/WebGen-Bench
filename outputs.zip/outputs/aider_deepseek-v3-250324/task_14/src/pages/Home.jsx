export default function Home() {
  return (
    <div className="container">
      <h1>Welcome to Our Clinical Office</h1>
      <p>Providing compassionate and professional healthcare services for our community.</p>
      <section>
        <h2>Our Mission</h2>
        <p>To deliver high-quality medical care with a patient-centered approach.</p>
      </section>
    </div>
  )
}
