export default function Services() {
  const services = [
    "General Check-ups",
    "Preventive Care",
    "Chronic Disease Management",
    "Vaccinations",
    "Health Screenings",
    "Minor Procedures"
  ]

  return (
    <div className="container">
      <h1>Our Services</h1>
      <ul>
        {services.map((service, index) => (
          <li key={index}>{service}</li>
        ))}
      </ul>
    </div>
  )
}
