export const ivory = '#FFFFF0'
export const forestGreen = '#228B22'
