export const mockPosts = [
  {
    id: 1,
    title: 'Welcome to our forum!',
    content: 'This is the first post in our new forum. Feel free to introduce yourself!',
    author: 'admin',
    category: 'general',
    createdAt: '2023-11-01T10:00:00Z',
    replyCount: 2
  },
  {
    id: 2,
    title: 'React best practices',
    content: 'What are your favorite React patterns and best practices?',
    author: 'dev_user',
    category: 'tech',
    createdAt: '2023-11-02T14:30:00Z',
    replyCount: 1
  },
  {
    id: 3,
    title: 'Favorite sports teams',
    content: 'Which sports teams do you support and why?',
    author: 'sports_fan',
    category: 'sports',
    createdAt: '2023-11-03T09:15:00Z',
    replyCount: 0
  }
]

export const mockReplies = [
  {
    id: 1,
    postId: 1,
    content: 'Thanks for creating this forum! Looking forward to great discussions.',
    author: 'user1',
    createdAt: '2023-11-01T11:30:00Z'
  },
  {
    id: 2,
    postId: 1,
    content: 'Hello everyone! Excited to be here.',
    author: 'user2',
    createdAt: '2023-11-01T12:45:00Z'
  },
  {
    id: 3,
    postId: 2,
    content: 'I love using custom hooks for reusable logic!',
    author: 'react_dev',
    createdAt: '2023-11-02T15:00:00Z'
  }
]

export const mockUser = {
  id: 1,
  username: 'current_user',
  email: 'user@example.com',
  posts: [1, 3],
  replies: [2]
}
