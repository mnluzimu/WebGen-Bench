const ReplyCard = ({ reply }) => {
  return (
    <div style={{ 
      backgroundColor: 'white',
      border: '1px solid slategray',
      padding: '15px',
      borderRadius: '8px'
    }}>
      <p style={{ margin: '0 0 10px 0', fontStyle: 'italic' }}>
        {reply.author} replied on {new Date(reply.createdAt).toLocaleDateString()}
      </p>
      <p style={{ margin: 0 }}>{reply.content}</p>
    </div>
  )
}

export default ReplyCard
