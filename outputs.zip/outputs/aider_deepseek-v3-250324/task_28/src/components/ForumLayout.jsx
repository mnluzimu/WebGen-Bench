import { Outlet, Link } from 'react-router-dom'
import Navbar from './Navbar'

const ForumLayout = () => {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar />
      <main style={{ flex: 1, padding: '20px' }}>
        <Outlet />
      </main>
      <footer style={{ 
        backgroundColor: 'slategray', 
        color: 'white', 
        padding: '10px', 
        textAlign: 'center' 
      }}>
        © 2023 Forum Webpage
      </footer>
    </div>
  )
}

export default ForumLayout
