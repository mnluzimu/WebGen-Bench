import { Link } from 'react-router-dom'
import './Navigation.css'

const Navigation = () => {
  return (
    <nav className="navigation">
      <Link to="/">Base</Link>
      <Link to="/ranking">Ranking</Link>
      <Link to="/store">Store</Link>
      <Link to="/train">Train</Link>
      <Link to="/workers">Workers</Link>
      <Link to="/upgrades">Upgrades</Link>
      <Link to="/bank">Bank</Link>
      <Link to="/messages">Messages</Link>
      <Link to="/reports">Reports</Link>
    </nav>
  )
}

export default Navigation
