import { Box, Typography } from '@mui/material'

const Dashboard = () => {
  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom color="primary">
        Travel Dashboard
      </Typography>
      <Typography>
        Welcome to the Travel Reimbursement System. Use the navigation to manage your bookings and reimbursements.
      </Typography>
    </Box>
  )
}

export default Dashboard
