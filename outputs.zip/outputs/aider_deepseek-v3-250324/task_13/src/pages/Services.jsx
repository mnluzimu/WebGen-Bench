export default function Services() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Our Credit Repair Services</h1>
      
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-2 text-rosybrown">Credit Report Analysis</h2>
          <p>We thoroughly examine your credit reports from all three bureaus to identify errors and opportunities for improvement.</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-2 text-rosybrown">Dispute Process</h2>
          <p>We handle all communication with credit bureaus to dispute inaccuracies and questionable items on your behalf.</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-2 text-rosybrown">Creditor Interventions</h2>
          <p>We negotiate with creditors to remove negative items and improve your credit standing.</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-2 text-rosybrown">Credit Education</h2>
          <p>We provide personalized guidance to help you maintain and improve your credit score long-term.</p>
        </div>
      </div>
    </div>
  )
}
