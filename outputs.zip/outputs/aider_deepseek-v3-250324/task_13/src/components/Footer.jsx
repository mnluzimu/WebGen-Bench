export default function Footer() {
  return (
    <footer className="bg-rosybrown text-white p-4 text-center">
      <p>© {new Date().getFullYear()} Credit Repair Pro. All rights reserved.</p>
    </footer>
  )
}
