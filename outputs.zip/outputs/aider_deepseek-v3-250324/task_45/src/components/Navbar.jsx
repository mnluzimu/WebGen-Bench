import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <nav style={{ backgroundColor: 'indianred', padding: '10px' }}>
      <ul style={{ display: 'flex', listStyle: 'none', gap: '20px' }}>
        <li><Link to="/" style={{ color: 'white', textDecoration: 'none' }}>Dashboard</Link></li>
        <li><Link to="/financial" style={{ color: 'white', textDecoration: 'none' }}>Financial</Link></li>
        <li><Link to="/reports" style={{ color: 'white', textDecoration: 'none' }}>Reports</Link></li>
        <li><Link to="/pharmacy" style={{ color: 'white', textDecoration: 'none' }}>Pharmacy</Link></li>
        <li><Link to="/patients" style={{ color: 'white', textDecoration: 'none' }}>Patients</Link></li>
        <li><Link to="/laboratory" style={{ color: 'white', textDecoration: 'none' }}>Laboratory</Link></li>
        <li><Link to="/theater" style={{ color: 'white', textDecoration: 'none' }}>Theater</Link></li>
      </ul>
    </nav>
  )
}
