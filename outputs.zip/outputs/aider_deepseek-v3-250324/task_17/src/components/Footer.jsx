export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p>© 2023 CleanHome Services. All rights reserved.</p>
        <p>Contact us: info@cleanhome.com | (555) 123-4567</p>
      </div>
    </footer>
  )
}
