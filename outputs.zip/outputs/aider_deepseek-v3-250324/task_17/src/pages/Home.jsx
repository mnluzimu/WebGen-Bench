export default function Home() {
  return (
    <div className="home">
      <h1>Welcome to CleanHome Services</h1>
      <p>Professional cleaning services for your home</p>
      <div className="card">
        <h2>Why Choose Us?</h2>
        <ul>
          <li>Professional and reliable cleaners</li>
          <li>Eco-friendly cleaning products</li>
          <li>Flexible scheduling</li>
          <li>Affordable pricing</li>
        </ul>
      </div>
    </div>
  )
}
