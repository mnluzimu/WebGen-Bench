import { Link } from 'react-router-dom'
import '../App.css'

export default function Navbar() {
  return (
    <nav className="component">
      <Link to="/">Trading Dashboard</Link>
      <Link to="/account">Account Management</Link>
      <Link to="/history">Trading History</Link>
    </nav>
  )
}
