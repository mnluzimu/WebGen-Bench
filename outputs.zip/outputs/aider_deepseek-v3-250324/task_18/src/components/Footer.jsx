export default function Footer() {
  return (
    <footer style={{ 
      backgroundColor: '#b22222', 
      color: 'white', 
      padding: '2rem 0', 
      marginTop: '2rem'
    }}>
      <div className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '2rem' }}>
          <div style={{ flex: 1 }}>
            <h3 style={{ marginBottom: '1rem' }}>TechSolutions Pro</h3>
            <p>Providing innovative software and staffing solutions for small to medium businesses.</p>
          </div>
          
          <div style={{ flex: 1 }}>
            <h3 style={{ marginBottom: '1rem' }}>Quick Links</h3>
            <ul style={{ listStyle: 'none' }}>
              <li style={{ marginBottom: '0.5rem' }}><a href="/about" style={{ color: 'white' }}>About Us</a></li>
              <li style={{ marginBottom: '0.5rem' }}><a href="/services" style={{ color: 'white' }}>Services</a></li>
              <li style={{ marginBottom: '0.5rem' }}><a href="/contact" style={{ color: 'white' }}>Contact</a></li>
            </ul>
          </div>
          
          <div style={{ flex: 1 }}>
            <h3 style={{ marginBottom: '1rem' }}>Contact Us</h3>
            <p>Email: info@techsolutionspro.com</p>
            <p>Phone: (123) 456-7890</p>
          </div>
        </div>
        
        <div style={{ textAlign: 'center', marginTop: '2rem', paddingTop: '1rem', borderTop: '1px solid rgba(255,255,255,0.2)' }}>
          <p>&copy; {new Date().getFullYear()} TechSolutions Pro. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
