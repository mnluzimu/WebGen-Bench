import './Home.css'

export default function Home() {
  return (
    <div className="home">
      <h1>Stock Report Generator</h1>
      <p>Generate customized stock reports with market trends and financial data</p>
    </div>
  )
}
