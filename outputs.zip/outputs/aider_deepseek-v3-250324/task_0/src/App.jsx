import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import ReportGenerator from './pages/ReportGenerator'
import Navbar from './components/Navbar'
import './App.css'

function App() {
  return (
    <div className="app">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/generate" element={<ReportGenerator />} />
        </Routes>
      </main>
    </div>
  )
}

export default App
